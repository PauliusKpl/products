<?php

namespace App\Http\Controllers;

use App\Models\Product;
use Illuminate\Http\Request;
use App\Models\Category;

class ProductController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function admin(){
        $categories = Category::all();
        $products = Product::all();
        return view('admin.index', ['categories' => $categories, 'products' => $products]); 
    }

    public function index(Request $request)
    {
        $categories = Category::all();
        $products = Product::all();
        if($request->category != null){
        $products = Product::where('category', $request->category)->get();
           }
        return view('products.index', ['categories' => $categories, 'products' => $products]); 
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\Product  $product
     * @return \Illuminate\Http\Response
     */
    public function show(Product $product)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\Product  $product
     * @return \Illuminate\Http\Response
     */
    public function edit(Product $product)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\Product  $product
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Product $product)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\Product  $product
     * @return \Illuminate\Http\Response
     */
    public function destroy(Product $product)
    {
        //
    }









public function createProduct(){
    $categories = Category::all();
    return view('admin.createProduct', ['categories' => $categories]);
}

public function storeProduct(Request $request){
    $categories = Category::all();
    $products = Product::all();

    $request->validate([
        'category' => 'required',
        'title' => 'required|min:2|max:50',
        'price' => 'required|numeric',
        'description' => 'required||min:2|max:255'
    ]);

    $validateCategory = Category::where('title', $request->category)->get();
    if($validateCategory->count() == 0) return('Klaida! Tokios kategorijos nera.');

   
    $store = new Product;
    $store->category = $request->category;
    $store->title = $request->title;
    $store->price = $request->price;
    $store->description = $request->description;
    $store->save();

    
    return(redirect('/admin'));
}

public function editProduct($id){
    $categories = Category::all();

   $product = Product::find($id);
   if($product == null) abort(404);

    
    return view('admin.editProduct', ['categories' => $categories, 'product' => $product]);
}

public function updateProduct($id, Request $request){
    $categories = Category::all();

    $store = Product::find($id);
    if($store == null) abort(404);

   $request->validate([
    'category' => 'required',
    'title' => 'required|min:2|max:50',
    'price' => 'required|numeric',
    'description' => 'required||min:2|max:255'
    ]);

    $validateCategory = Category::where('title', $request->category)->get();
    if($validateCategory->count() == 0) return('Klaida! Tokios kategorijos nera.');
   
    $store->category = $request->category;
    $store->title = $request->title;
    $store->price = $request->price;
    $store->description = $request->description;
    $store->save();

    
    return(redirect('/admin'));
}

public function deleteProduct($id){
    $product = Product::find($id);
    if($product == null) abort(404);

    return view('admin.deleteProduct', ['product' => $product]);
}

public function removeProduct($id){
    $product = Product::find($id);
    if($product == null) abort(404);
    $product->delete();

    return redirect('/admin');
}

}