<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Category;
use App\Models\Product;


class CategoryController extends Controller
{
    public function createCategory(){
        return view('admin.createCategory');
    }

    public function storeCategory(Request $request){
        $request->validate(['title' => 'required|unique:categories,title|min:2|max:100']);


        $store = new Category;
        $store->title = $request->title;
        $store->save();
        return(redirect('/admin'));
    }

    public function editCategory($id){
        $category = Category::find($id);
        if($category == null) abort(404);

        return view('admin.editCategory', ['category' => $category]);
    }

    public function UpdateCategory($id, Request $request){


        $store = Category::find($id);
        if($store == null) abort(404);

        $categories = Product::where('category', $store->title)->get();

        $request->validate(['title' => 'required|unique:categories,title|min:2|max:100']);

        foreach($categories as $category)
        {$category->category = $request->title; $category->save();}

        $store->title = $request->title;
        $store->save();
        return(redirect('/admin'));
    }

    public function deleteCategory($id){
        $category = Category::find($id);
        if($category == null) abort(404);

        return view('admin.deleteCategory', ['category' => $category]);
    }

    public function removeCategory($id){
        $category = Category::find($id);
        if($category == null) abort(404);

        $category->delete();
        return(redirect('/admin'));
    }



}