<?php

use App\Http\Controllers\ProductController;
use App\Http\Controllers\CategoryController;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', [ProductController::class, 'index']);
Route::get('/admin', [ProductController::class, 'admin']);

Route::get('/admin/createCategory', [CategoryController::class, 'createCategory']);
Route::post('/admin/createCategory', [CategoryController::class, 'storeCategory']);
Route::get('/admin/editCategory/{id}', [CategoryController::class, 'editCategory']);
Route::post('/admin/editCategory/{id}', [CategoryController::class, 'updateCategory']);
Route::get('/admin/deleteCategory/{id}', [CategoryController::class, 'deleteCategory']);
Route::post('/admin/deleteCategory/{id}', [CategoryController::class, 'removeCategory']);

Route::get('/admin/createProduct', [ProductController::class, 'createProduct']);
Route::post('/admin/createProduct', [ProductController::class, 'storeProduct']);
Route::get('/admin/editProduct/{id}', [ProductController::class, 'editProduct']);
Route::post('/admin/editProduct/{id}', [ProductController::class, 'updateProduct']);
Route::get('/admin/deleteProduct/{id}', [ProductController::class, 'deleteProduct']);
Route::post('/admin/deleteProduct/{id}', [ProductController::class, 'removeProduct']);