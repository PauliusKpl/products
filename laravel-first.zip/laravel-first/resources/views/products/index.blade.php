@extends('layout')
@section('content')

<h2 style="text-align: center">Produktai</h2>
@if($categories->count() == null)
<h3>Produktų nerasta.</h3>
@endif

@if(request()->category != null)
<a href="/">Rodyti visus produktus</a>
@endif

@foreach($products as $product)
<div class="product">
    <p>pavadinimas: {{$product->title}}</p>
    <p>kaina: € {{$product->price}}</p>
    <p>aprasymas: {{$product->description}}</p>
</div>
</div>

<style>
    .product{
        border: 1px solid orange;
        margin-bottom: 5px;
        background-color: azure;
        width: 20%;
        margin: auto;
        padding: 5px;
        width: 80%;
        margin-bottom: 5px;
        margin-top: 5px;
        color: rgb(38, 4, 38);
        font-size: 20px;
        font-family: Georgia, 'Times New Roman', Times, serif
    }

</style>

@endforeach
@endsection