<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Products</title>
</head>
<body>
    <header>
        <a href="/admin">Prisijungti</a>
    </header>

    <div class="sidebar">
        <ul>
            <h3>Kategorijos</h3>
        @foreach($categories as $category)
        <a href="?category={{$category->title}}"><li>{{$category->title}}</li></a>
        @endforeach
        </ul>
    </div>

    @yield('content')

    <footer style="background-color: cadetblue; text-align: center; color: white;">
        <p>Paulius Kepalas ŽP 20/1v</p>
    </footer>
</body>

<style>
    body{
        margin: 0;
        padding: 0;
        box-sizing: border-box;
        height: 100%;
        width: 100%;
    }
    header{
        width: 100%;
        background-color: cadetblue;
        text-align: right;
        border-bottom: 2px solid orange;
    }
    header a{
        text-decoration: none;
        margin-right: 5px;
        font-size: 30px;
        color: rgb(255, 166, 0)
    }
    .sidebar{
        text-align: center;
        border-bottom: 2px solid orange;
        width: 100%;
        margin: auto;
        display:flex;
        justify-content: center;
    }
    .sidebar a{
        text-decoration: none;
    }

    .sidebar li{
        list-style: none;
        border: 1px solid rgb(205, 205, 205);
        padding: 5px;
    }
    .sidebar li:hover{
        background-color: aliceblue;
    }
    .sidebar ul{
        list-style: none;
        width: 30%;
    }
</style>

</html>