@if($categories->count() == 0)
<h1>Kategoriju nerasta.</h1>
<form action="/admin/createCategory"><button>Sukurti kategorija</button></form>
@else
<form action="/admin/editProduct/{{$product->id}}" method="post">
    @csrf
    <select name="category">
    <option value="{{$product->category}}">Pasirinkite kategorija</option>
        @foreach($categories as $category)
        <option>{{$category->title}}</option>
        @endforeach
    </select>
    <br>
   <label for="title">Pavadinimas <input type="text" name="title" placeholder="Pavadinimas" value="{{$product->title}}"> </label>
   <br>
   <label for="price">Kaina <input type="text" name="price" placeholder="Kaina" value="{{$product->price}}"></label>
   <br>
   <textarea name="description" placeholder="Aprasymas" value="{{$product->description}}"></textarea>
   <br>
    <button>Issaugoti</button>
</form>

@foreach($errors->all() as $err)
<p style="color:red">{{$err}}</p>
@endforeach

@endif