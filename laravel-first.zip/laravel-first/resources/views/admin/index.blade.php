@extends('layout')
@section('content')
<div style="text-align: center; background-color: rgb(228, 228, 228)">
<h1>Admin</h1>

<form action="/admin/createProduct">
    <button>Sukurti Produkta</button>
</form>

<form action="/admin/createCategory">
    <button>Sukurti kategorija</button>
</form>

<hr>


<h2>Kategorijos</h2>
@foreach($categories as $category)
<p>pavadinimas: {{$category->title}}</p>
<form action="admin/editCategory/{{$category->id}}"><button>Redaguoti</button></form>
<form action="admin/deleteCategory/{{$category->id}}"><button>Istrinti</button></form>
<hr>
@endforeach
<hr style="height: 5px; background-color: rgb(18, 18, 18)">
<h2>Produktai</h2>
@foreach($products as $product)
<p>kategorija: {{$product->category}}</p>
<p>pavadinimas: {{$product->title}}</p>
<p>kaina: {{$product->price}}</p>
<p>aprasymas: {{$product->description}}</p>
<form action="admin/editProduct/{{$product->id}}"><button>Redaguoti</button></form>
<form action="admin/deleteProduct/{{$product->id}}"><button>Istrinti</button></form>
<hr>
@endforeach
</div>

@endsection