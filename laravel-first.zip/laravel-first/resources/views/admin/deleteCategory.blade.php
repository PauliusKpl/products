
<h1>Ar tikrai norite ištrinti "{{$category->title}}" kategoriją? Visi produktai susieti su šia kategorija bus ištrinti.</h1>
<form action="/admin"><button>Ne</button></form>
<form action="/admin/deleteCategory/{{$category->id}}" method="post">
    @csrf
    <button>Taip</button>
</form>

@foreach($errors->all() as $err)
<p style="color:red">{{$err}}</p>
@endforeach