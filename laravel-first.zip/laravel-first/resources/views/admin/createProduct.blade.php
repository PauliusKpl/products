@if($categories->count() == 0)
<h1>Kategoriju nerasta.</h1>
<form action="/admin/createCategory"><button>Sukurti kategorija</button></form>
@else
<form action="/admin/createProduct" method="post">
    @csrf
    <select name="category">
    <option value="">Pasirinkite kategorija</option>
        @foreach($categories as $category)
        <option>{{$category->title}}</option>
        @endforeach
    </select>
    <br>
   <label for="title">Pavadinimas <input type="text" name="title" placeholder="Pavadinimas"> </label>
   <br>
   <label for="price">Kaina <input type="text" name="price" placeholder="Kaina"></label>
   <br>
   <textarea name="description" placeholder="Aprasymas"></textarea>
   <br>
    <button>Issaugoti</button>
</form>

<style>
</style>

@foreach($errors->all() as $err)
<p style="color:red">{{$err}}</p>
@endforeach

@endif