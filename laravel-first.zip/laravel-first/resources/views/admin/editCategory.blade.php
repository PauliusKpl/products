

<form action="/admin/editCategory/{{$category->id}}" method="post">
    @csrf
    <input type="text" name="title" placeholder="Kategorija">

    <button>Issaugoti</button>
</form>

@foreach($errors->all() as $err)
<p style="color:red">{{$err}}</p>
@endforeach