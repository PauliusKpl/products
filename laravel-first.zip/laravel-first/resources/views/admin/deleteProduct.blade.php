
<h1>Ar tikrai norite ištrinti "{{$product->title}}" Produkta?</h1>
<form action="/admin"><button>Ne</button></form>
<form action="/admin/deleteProduct/{{$product->id}}" method="post">
    @csrf
    <button>Taip</button>
</form>

@foreach($errors->all() as $err)
<p style="color:red">{{$err}}</p>
@endforeach
