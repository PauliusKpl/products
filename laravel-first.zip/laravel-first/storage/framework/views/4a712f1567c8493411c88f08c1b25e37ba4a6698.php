<?php if($categories->count() == 0): ?>
<h1>Kategoriju nerasta.</h1>
<form action="/admin/createCategory"><button>Sukurti kategorija</button></form>
<?php else: ?>
<form action="/admin/editProduct/<?php echo e($product->id); ?>" method="post">
    <?php echo csrf_field(); ?>
    <select name="category">
    <option value="<?php echo e($product->category); ?>">Pasirinkite kategorija</option>
        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <option><?php echo e($category->title); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
    <br>
   <label for="title">Pavadinimas <input type="text" name="title" placeholder="Pavadinimas" value="<?php echo e($product->title); ?>"> </label>
   <br>
   <label for="price">Kaina <input type="text" name="price" placeholder="Kaina" value="<?php echo e($product->price); ?>"></label>
   <br>
   <textarea name="description" placeholder="Aprasymas" value="<?php echo e($product->description); ?>"></textarea>
   <br>
    <button>Issaugoti</button>
</form>

<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $err): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<p style="color:red"><?php echo e($err); ?></p>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php endif; ?><?php /**PATH /opt/lampp/htdocs/laravel/laravel-first/resources/views/admin/editProduct.blade.php ENDPATH**/ ?>