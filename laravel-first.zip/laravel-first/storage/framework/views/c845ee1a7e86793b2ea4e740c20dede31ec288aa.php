<?php $__env->startSection('content'); ?>
<div style="text-align: center; background-color: rgb(228, 228, 228)">
<h1>Admin</h1>

<form action="/admin/createProduct">
    <button>Sukurti Produkta</button>
</form>

<form action="/admin/createCategory">
    <button>Sukurti kategorija</button>
</form>

<hr>


<h2>Kategorijos</h2>
<?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<p>pavadinimas: <?php echo e($category->title); ?></p>
<form action="admin/editCategory/<?php echo e($category->id); ?>"><button>Redaguoti</button></form>
<form action="admin/deleteCategory/<?php echo e($category->id); ?>"><button>Istrinti</button></form>
<hr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<hr style="height: 5px; background-color: rgb(18, 18, 18)">
<h2>Produktai</h2>
<?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<p>kategorija: <?php echo e($product->category); ?></p>
<p>pavadinimas: <?php echo e($product->title); ?></p>
<p>kaina: <?php echo e($product->price); ?></p>
<p>aprasymas: <?php echo e($product->description); ?></p>
<form action="admin/editProduct/<?php echo e($product->id); ?>"><button>Redaguoti</button></form>
<form action="admin/deleteProduct/<?php echo e($product->id); ?>"><button>Istrinti</button></form>
<hr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/laravel/laravel-first/resources/views/admin/index.blade.php ENDPATH**/ ?>