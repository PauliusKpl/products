

<form action="/admin/editCategory/<?php echo e($category->id); ?>" method="post">
    <?php echo csrf_field(); ?>
    <input type="text" name="title" placeholder="Kategorija">

    <button>Issaugoti</button>
</form>

<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $err): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<p style="color:red"><?php echo e($err); ?></p>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php /**PATH /opt/lampp/htdocs/laravel/laravel-first/resources/views/admin/editCategory.blade.php ENDPATH**/ ?>