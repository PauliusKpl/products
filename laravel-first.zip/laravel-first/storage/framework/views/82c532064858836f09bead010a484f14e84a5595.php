
<h1>Ar tikrai norite ištrinti "<?php echo e($product->title); ?>" Produkta?</h1>
<form action="/admin"><button>Ne</button></form>
<form action="/admin/deleteProduct/<?php echo e($product->id); ?>" method="post">
    <?php echo csrf_field(); ?>
    <button>Taip</button>
</form>

<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $err): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<p style="color:red"><?php echo e($err); ?></p>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php /**PATH /opt/lampp/htdocs/laravel/laravel-first/resources/views/admin/deleteProduct.blade.php ENDPATH**/ ?>