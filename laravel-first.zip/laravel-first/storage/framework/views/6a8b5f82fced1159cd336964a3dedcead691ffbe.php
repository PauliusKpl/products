
<h1>Ar tikrai norite ištrinti "<?php echo e($category->title); ?>" kategoriją? Visi produktai susieti su šia kategorija bus ištrinti.</h1>
<form action="/admin"><button>Ne</button></form>
<form action="/admin/deleteCategory/<?php echo e($category->id); ?>" method="post">
    <?php echo csrf_field(); ?>
    <button>Taip</button>
</form>

<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $err): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<p style="color:red"><?php echo e($err); ?></p>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php /**PATH /opt/lampp/htdocs/laravel/laravel-first/resources/views/admin/deleteCategory.blade.php ENDPATH**/ ?>