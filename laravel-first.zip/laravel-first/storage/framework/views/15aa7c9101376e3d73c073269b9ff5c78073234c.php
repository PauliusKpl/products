<?php $__env->startSection('content'); ?>

<h2 style="text-align: center">Produktai</h2>
<?php if($categories->count() == null): ?>
<h3>Produktų nerasta.</h3>
<?php endif; ?>

<?php if(request()->category != null): ?>
<a href="/">Rodyti visus produktus</a>
<?php endif; ?>

<?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="product">
    <p>pavadinimas: <?php echo e($product->title); ?></p>
    <p>kaina: € <?php echo e($product->price); ?></p>
    <p>aprasymas: <?php echo e($product->description); ?></p>
</div>
</div>

<style>
    .product{
        border: 1px solid orange;
        margin-bottom: 5px;
        background-color: azure;
        width: 20%;
        margin: auto;
        padding: 5px;
        width: 80%;
        margin-bottom: 5px;
        margin-top: 5px;
        color: rgb(38, 4, 38);
        font-size: 20px;
        font-family: Georgia, 'Times New Roman', Times, serif
    }

</style>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/laravel/laravel-first/resources/views/products/index.blade.php ENDPATH**/ ?>