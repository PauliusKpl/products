#ddev-generated
Scripts in this directory will be executed inside the web
container. You can copy the example file or just rename it:
`mv reload-nginx.example reload-nginx`, for example, and "ddev reload-nginx" will become
a live command.

See https://ddev.readthedocs.io/en/stable/users/extend/custom-commands/#environment-variables-provided for a list of environment variables that can be used in the scripts.
